"""Temporal preprocessing (main text Section 2.2.1; Supplementary Table S2).

- Forward-fill within a 6-hour window, then backward-fill.
- Residual missing imputed with cohort median (computed on TRAIN only).
- Per-feature z-score standardisation using TRAIN statistics.
- Assemble (N, 24, 24) tensors: 24 time steps x (8 vitals + 16 labs).
"""
import numpy as np
import pandas as pd

N_STEPS = 24


def forward_backward_fill(seq: np.ndarray, window: int = 6) -> np.ndarray:
    """seq: (T, F) with NaNs. Forward-fill <=window, then backward-fill."""
    df = pd.DataFrame(seq)
    df = df.ffill(limit=window).bfill()
    return df.values


def fit_imputation_stats(train_sequences: np.ndarray) -> np.ndarray:
    """Cohort median per feature on TRAIN (ignoring NaN)."""
    return np.nanmedian(train_sequences.reshape(-1, train_sequences.shape[-1]), axis=0)


def fit_scaler(train_sequences: np.ndarray):
    flat = train_sequences.reshape(-1, train_sequences.shape[-1])
    mean = np.nanmean(flat, axis=0)
    std = np.nanstd(flat, axis=0)
    std[std == 0] = 1.0
    return mean, std


def transform_sequences(sequences: np.ndarray, medians, mean, std,
                        fill_window: int = 6):
    out = np.empty_like(sequences, dtype=np.float32)
    mask = np.ones((sequences.shape[0], sequences.shape[1]), dtype=np.float32)
    for i in range(sequences.shape[0]):
        s = forward_backward_fill(sequences[i], window=fill_window)
        # any remaining NaN -> cohort median; record mask of originally-missing steps
        step_missing = np.isnan(sequences[i]).all(axis=1)
        mask[i] = (~step_missing).astype(np.float32)
        inds = np.where(np.isnan(s))
        s[inds] = np.take(medians, inds[1])
        out[i] = (s - mean) / std
    return out, mask
