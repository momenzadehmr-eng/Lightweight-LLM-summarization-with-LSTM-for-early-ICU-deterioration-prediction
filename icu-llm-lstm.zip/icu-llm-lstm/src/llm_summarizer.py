"""Template-guided Flan-T5-Large summarization (Supplementary S1.3 - S1.4).

Deterministic decoding (greedy) constrains outputs to five structured fields,
reducing hallucination relative to free-form generation.
"""
import torch
from transformers import T5Tokenizer, T5ForConditionalGeneration


SYSTEM_PROMPT = (
    "You are a clinical summarization assistant. Extract structured information "
    "from the following ICU clinical note. Be concise and factual. Do not infer "
    "or add information not explicitly stated in the note."
)

TASK_PROMPT = (
    "TASK: Summarize the following ICU clinical note and extract:\n"
    "1. Primary reason for admission (maximum 10 words)\n"
    "2. Significant comorbidities (list up to 5, semicolon-separated)\n"
    "3. Current clinical status: choose exactly one of [stable / moderate / critical]\n"
    "4. Active interventions (list up to 5, semicolon-separated)\n"
    "5. Documented concerns or red flags (list up to 3, semicolon-separated)\n\n"
    "CLINICAL NOTE:\n{note_text}\n\n"
    "OUTPUT (use exactly this format, no additional text):\n"
    "Admission: [text]\n"
    "Comorbidities: [list or NONE]\n"
    "Status: [stable|moderate|critical]\n"
    "Interventions: [list or NONE]\n"
    "Concerns: [list or NONE]"
)


def build_prompt(note_text: str) -> str:
    return f"SYSTEM: {SYSTEM_PROMPT}\n\n{TASK_PROMPT.format(note_text=note_text)}"


class TemplateSummarizer:
    def __init__(self, cfg: dict, device=None):
        ckpt = cfg["llm"]["base_checkpoint"]
        self.tokenizer = T5Tokenizer.from_pretrained(ckpt)
        self.model = T5ForConditionalGeneration.from_pretrained(ckpt)
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.model.to(self.device).eval()
        self.max_input = cfg["llm"]["max_input_tokens"]
        self.dec = cfg["llm"]["decoding"]

    @torch.no_grad()
    def summarize_batch(self, notes, batch_size: int = 64):
        outputs = []
        for i in range(0, len(notes), batch_size):
            chunk = notes[i:i + batch_size]
            prompts = [build_prompt(n) for n in chunk]
            enc = self.tokenizer(
                prompts, return_tensors="pt", padding=True,
                truncation=True, max_length=self.max_input,
            ).to(self.device)
            gen = self.model.generate(
                **enc,
                max_new_tokens=256,
                do_sample=self.dec["do_sample"],
                temperature=self.dec["temperature"] or 1.0,
                top_p=self.dec["top_p"],
                num_beams=self.dec["num_beams"],
            )
            outputs.extend(self.tokenizer.batch_decode(gen, skip_special_tokens=True))
        return outputs


def parse_summary(text: str) -> dict:
    """Parse the 5 structured fields from a generated summary."""
    fields = {"Admission": "", "Comorbidities": "NONE", "Status": "moderate",
              "Interventions": "NONE", "Concerns": "NONE"}
    for line in text.splitlines():
        if ":" in line:
            k, _, v = line.partition(":")
            k = k.strip()
            if k in fields:
                fields[k] = v.strip()
    # Validate status against the enumerated vocabulary
    if fields["Status"].lower() not in {"stable", "moderate", "critical"}:
        fields["Status"] = "moderate"
    return fields
