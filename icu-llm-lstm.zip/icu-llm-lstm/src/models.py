"""Model architecture (Supplementary S1.6 - S1.8).

Components
---------
1. TemporalEncoder  : 2-layer BiLSTM (128 units/dir) + LayerNorm + dropout
2. AdditiveAttention: additive (Bahdanau-style) attention over 24 time steps
3. TextEncoder      : 2-layer FFN projecting the 256-dim LLM embedding
4. FusionMultiTask  : concat -> shared trunk -> 3 independent task heads
"""
import torch
import torch.nn as nn


class AdditiveAttention(nn.Module):
    """e_t = v^T tanh(W_h h_t + b_h);  alpha = softmax(e);  c = sum alpha_t h_t."""

    def __init__(self, hidden_dim: int = 256, attn_dim: int = 64):
        super().__init__()
        self.W_h = nn.Linear(hidden_dim, attn_dim, bias=True)   # 256 -> 64
        self.v = nn.Linear(attn_dim, 1, bias=False)             # 64 -> 1
        nn.init.xavier_uniform_(self.W_h.weight)
        nn.init.zeros_(self.W_h.bias)
        nn.init.xavier_uniform_(self.v.weight)

    def forward(self, H, mask=None):
        # H: (B, T, hidden_dim)
        scores = self.v(torch.tanh(self.W_h(H))).squeeze(-1)    # (B, T)
        if mask is not None:
            scores = scores.masked_fill(mask == 0, float("-inf"))
        alpha = torch.softmax(scores, dim=1)                    # (B, T)
        context = torch.bmm(alpha.unsqueeze(1), H).squeeze(1)   # (B, hidden_dim)
        return context, alpha


class TemporalEncoder(nn.Module):
    def __init__(self, n_features=24, hidden_per_dir=128, n_layers=2,
                 dropout=0.3, attn_dim=64):
        super().__init__()
        hidden = hidden_per_dir * 2  # bidirectional -> 256
        self.lstm = nn.LSTM(
            input_size=n_features,
            hidden_size=hidden_per_dir,
            num_layers=n_layers,
            batch_first=True,
            bidirectional=True,
            dropout=dropout if n_layers > 1 else 0.0,
        )
        self.layernorm = nn.LayerNorm(hidden)
        self.dropout = nn.Dropout(dropout)
        self.attention = AdditiveAttention(hidden_dim=hidden, attn_dim=attn_dim)
        self.out_dim = hidden

    def forward(self, x, mask=None):
        # x: (B, T=24, F=24)
        h, _ = self.lstm(x)                 # (B, T, 256)
        h = self.layernorm(h)
        h = self.dropout(h)
        context, alpha = self.attention(h, mask)
        return context, alpha               # (B, 256), (B, T)


class TextEncoder(nn.Module):
    """Two-layer FFN on the 256-dim LLM-derived embedding."""

    def __init__(self, in_dim=256, hidden=256, out_dim=256, dropout=0.3):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, out_dim),
            nn.ReLU(),
        )
        self.out_dim = out_dim

    def forward(self, e):
        return self.net(e)                  # (B, 256)


class TaskHead(nn.Module):
    def __init__(self, in_dim=128, hidden=64, dropout=0.2):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, 1),
        )

    def forward(self, x):
        return self.net(x).squeeze(-1)      # (B,)


class MultimodalLSTM(nn.Module):
    """Full multimodal multi-task model."""

    def __init__(self, cfg: dict):
        super().__init__()
        te = cfg["temporal_encoder"]
        at = cfg["attention"]
        fu = cfg["fusion"]
        emb_dim = cfg["embedding"]["total_dim"]

        self.temporal = TemporalEncoder(
            n_features=te["input_features"],
            hidden_per_dir=te["lstm_hidden_per_direction"],
            n_layers=te["n_lstm_layers"],
            dropout=te["dropout"],
            attn_dim=at["hidden_dim"],
        )
        self.text = TextEncoder(in_dim=emb_dim, hidden=emb_dim,
                                out_dim=emb_dim, dropout=te["dropout"])

        concat_dim = self.temporal.out_dim + self.text.out_dim  # 256 + 256
        self.shared = nn.Sequential(
            nn.Linear(concat_dim, fu["shared_dim"]),
            nn.ReLU(),
            nn.BatchNorm1d(fu["shared_dim"]),
            nn.Dropout(fu["shared_dropout"]),
        )
        self.tasks = fu["tasks"]
        self.heads = nn.ModuleDict({
            t: TaskHead(in_dim=fu["shared_dim"],
                        hidden=fu["head_hidden"],
                        dropout=fu["head_dropout"])
            for t in self.tasks
        })

    def forward(self, x_seq, emb, mask=None, return_attention=False):
        ctx, alpha = self.temporal(x_seq, mask)
        txt = self.text(emb)
        fused = torch.cat([ctx, txt], dim=1)
        shared = self.shared(fused)
        logits = {t: self.heads[t](shared) for t in self.tasks}
        if return_attention:
            return logits, alpha
        return logits


def build_text_only(cfg):
    """LLM-only baseline: classifier on the 256-dim embedding."""
    emb_dim = cfg["embedding"]["total_dim"]
    tasks = cfg["fusion"]["tasks"]
    return _SingleModalMultiTask(emb_dim, tasks)


class _SingleModalMultiTask(nn.Module):
    def __init__(self, in_dim, tasks):
        super().__init__()
        self.trunk = nn.Sequential(
            nn.Linear(in_dim, 128), nn.ReLU(),
            nn.BatchNorm1d(128), nn.Dropout(0.3),
        )
        self.heads = nn.ModuleDict({t: TaskHead(128) for t in tasks})
        self.tasks = tasks

    def forward(self, emb):
        h = self.trunk(emb)
        return {t: self.heads[t](h) for t in self.tasks}
