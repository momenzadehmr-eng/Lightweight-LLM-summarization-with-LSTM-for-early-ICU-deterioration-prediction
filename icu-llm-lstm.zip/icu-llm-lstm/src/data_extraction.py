"""Cohort build and exclusion-flow orchestration (main text Section 2.1).

Runs the SQL extraction scripts against a local MIMIC-IV PostgreSQL instance,
then applies the Python-side exclusions (>6h consecutive vital-sign gaps,
incomplete outcome labels) producing the final analytic cohort and the
Fig. S1 exclusion counts.
"""
import argparse
import numpy as np
import pandas as pd

from .utils import load_config


def detect_long_gaps(vitals_long: pd.DataFrame, max_gap_h: int = 6) -> set:
    """Return stay_ids with > max_gap_h consecutive fully-missing hours."""
    bad = set()
    for stay_id, g in vitals_long.groupby("stay_id"):
        present_hours = set(g["hour_idx"].unique())
        run = 0
        for h in range(24):
            if h in present_hours:
                run = 0
            else:
                run += 1
                if run > max_gap_h:
                    bad.add(stay_id)
                    break
    return bad


def build_cohort(cfg: dict) -> pd.DataFrame:
    """Apply Python-side exclusions and report the Fig. S1 flow.

    Expects SQL stage tables to have been materialised already (see sql/).
    This function reads the exported CSVs from cfg['paths']['cohort_dir'].
    """
    cdir = cfg["paths"]["cohort_dir"]
    base = pd.read_csv(f"{cdir}/cohort_base.csv")          # post SQL stage 1-2
    vitals = pd.read_csv(f"{cdir}/vitals_hourly.csv")
    outcomes = pd.read_csv(f"{cdir}/outcomes.csv")

    flow = {"raw_stays": 73181, "after_sql_stages": len(base)}

    gap_bad = detect_long_gaps(vitals, cfg["cohort"]["max_consecutive_vital_gap_hours"])
    base = base[~base["stay_id"].isin(gap_bad)]
    flow["after_gap_exclusion"] = len(base)

    base = base.merge(outcomes, on="stay_id", how="inner").dropna(
        subset=["mortality", "shock", "ventilation"])
    flow["final_analytic_cohort"] = len(base)

    print("Cohort exclusion flow (Fig. S1):")
    for k, v in flow.items():
        print(f"  {k}: {v}")
    return base


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()
    cfg = load_config(args.config)
    build_cohort(cfg)
