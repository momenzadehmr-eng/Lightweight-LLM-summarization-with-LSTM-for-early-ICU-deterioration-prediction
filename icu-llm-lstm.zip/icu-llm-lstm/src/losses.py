"""Focal loss for class-imbalanced binary tasks (Supplementary S1.10.1).

L_focal = - alpha * (1 - p_t)^gamma * log(p_t)

gamma fixed at 2.0; per-task alpha set from validation (Table S12).
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class BinaryFocalLoss(nn.Module):
    def __init__(self, alpha: float = 0.5, gamma: float = 2.0,
                 reduction: str = "mean"):
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        # logits, targets: (B,)
        bce = F.binary_cross_entropy_with_logits(logits, targets, reduction="none")
        p = torch.sigmoid(logits)
        p_t = p * targets + (1 - p) * (1 - targets)
        alpha_t = self.alpha * targets + (1 - self.alpha) * (1 - targets)
        loss = alpha_t * (1 - p_t).pow(self.gamma) * bce
        if self.reduction == "mean":
            return loss.mean()
        if self.reduction == "sum":
            return loss.sum()
        return loss


class MultiTaskFocalLoss(nn.Module):
    """Weighted sum of per-task focal losses."""

    def __init__(self, task_alphas: dict, task_weights: dict, gamma: float = 2.0):
        super().__init__()
        self.tasks = list(task_weights.keys())
        self.task_weights = task_weights
        self.losses = nn.ModuleDict({
            t: BinaryFocalLoss(alpha=task_alphas[t], gamma=gamma)
            for t in self.tasks
        })

    def forward(self, logits: dict, targets: dict) -> torch.Tensor:
        total = 0.0
        for t in self.tasks:
            total = total + self.task_weights[t] * self.losses[t](logits[t], targets[t])
        return total
