"""Clinical note processing (main text Section 2.2.2).

Steps: deidentification verification, section extraction, text cleaning.
No patient data is included in this repo; this operates on locally extracted
MIMIC-IV-Note text the credentialed user supplies.
"""
import re

PHI_PATTERNS = [
    re.compile(r"\[\*\*.*?\*\*\]"),     # MIMIC bracketed deid placeholders
    re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),  # SSN-like
]

SECTION_HEADERS = [
    "chief complaint", "history of present illness", "past medical history",
    "physical exam", "physical examination", "assessment", "plan",
    "assessment and plan", "impression", "hospital course",
]


def strip_residual_phi(text: str) -> str:
    for pat in PHI_PATTERNS:
        text = pat.sub(" ", text)
    return text


def extract_sections(text: str) -> dict:
    """Split a note into recognised clinical sections via header regex."""
    lower = text.lower()
    positions = []
    for h in SECTION_HEADERS:
        for m in re.finditer(rf"(?:^|\n)\s*{re.escape(h)}\s*[:\-]", lower):
            positions.append((m.start(), h))
    positions.sort()
    sections = {}
    for i, (start, h) in enumerate(positions):
        end = positions[i + 1][0] if i + 1 < len(positions) else len(text)
        sections[h] = text[start:end].strip()
    return sections


def clean_text(text: str) -> str:
    text = strip_residual_phi(text)
    text = re.sub(r"\s+", " ", text)          # standardise whitespace
    text = text.strip().lower()
    return text


def prepare_note(raw: str) -> str:
    cleaned = clean_text(raw)
    return cleaned
