"""Training loop (main text Section 2.5; Supplementary S1.9).

Adam, lr=1e-3, ExponentialLR(gamma=0.95) every 5 epochs, grad-clip 1.0,
batch 64, early stopping on summed validation AUPRC.
"""
import argparse
import copy
import numpy as np
import torch
from torch.utils.data import DataLoader, TensorDataset
from sklearn.metrics import average_precision_score

from .utils import load_config, set_seed, get_device
from .models import MultimodalLSTM
from .losses import MultiTaskFocalLoss


def make_loader(X_seq, mask, emb, y, batch_size, shuffle):
    ds = TensorDataset(
        torch.tensor(X_seq, dtype=torch.float32),
        torch.tensor(mask, dtype=torch.float32),
        torch.tensor(emb, dtype=torch.float32),
        torch.tensor(y, dtype=torch.float32),     # (N, 3) mortality/shock/vent
    )
    return DataLoader(ds, batch_size=batch_size, shuffle=shuffle)


def val_auprc_sum(model, loader, tasks, device):
    model.eval()
    probs = {t: [] for t in tasks}
    trues = {t: [] for t in tasks}
    with torch.no_grad():
        for X_seq, mask, emb, y in loader:
            X_seq, mask, emb = X_seq.to(device), mask.to(device), emb.to(device)
            logits = model(X_seq, emb, mask)
            for j, t in enumerate(tasks):
                probs[t].append(torch.sigmoid(logits[t]).cpu().numpy())
                trues[t].append(y[:, j].numpy())
    total = 0.0
    for t in tasks:
        p = np.concatenate(probs[t]); a = np.concatenate(trues[t])
        total += average_precision_score(a, p)
    return total


def train(cfg, data):
    set_seed(cfg["seed"])
    device = get_device()
    tasks = cfg["fusion"]["tasks"]
    tr = cfg["training"]

    model = MultimodalLSTM(cfg).to(device)
    criterion = MultiTaskFocalLoss(
        task_alphas=cfg["focal_loss"]["alpha"],
        task_weights=cfg["task_weights"],
        gamma=cfg["focal_loss"]["gamma"],
    ).to(device)

    opt = torch.optim.Adam(model.parameters(), lr=tr["learning_rate"])
    sched = torch.optim.lr_scheduler.StepLR(
        opt, step_size=tr["lr_step_epochs"], gamma=tr["lr_gamma"])

    train_loader = make_loader(*data["train"], tr["batch_size"], shuffle=True)
    val_loader = make_loader(*data["val"], tr["batch_size"], shuffle=False)

    best_score, best_state, patience = -1, None, 0
    for epoch in range(tr["max_epochs"]):
        model.train()
        for X_seq, mask, emb, y in train_loader:
            X_seq, mask, emb, y = (X_seq.to(device), mask.to(device),
                                   emb.to(device), y.to(device))
            opt.zero_grad()
            logits = model(X_seq, emb, mask)
            targets = {t: y[:, j] for j, t in enumerate(tasks)}
            loss = criterion(logits, targets)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), tr["grad_clip_norm"])
            opt.step()
        sched.step()

        score = val_auprc_sum(model, val_loader, tasks, device)
        print(f"epoch {epoch:02d}  val_auprc_sum={score:.4f}")
        if score > best_score:
            best_score, best_state, patience = score, copy.deepcopy(model.state_dict()), 0
        else:
            patience += 1
            if patience >= tr["early_stopping_patience"]:
                print("early stopping")
                break

    model.load_state_dict(best_state)
    return model


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()
    cfg = load_config(args.config)
    print("Load preprocessed tensors into a `data` dict with keys "
          "'train'/'val'/'test', each a tuple (X_seq, mask, emb, y), then call train(cfg, data).")
