"""Sensitivity analyses (reviewer-requested).

Re-trains/evaluates the model under varied design choices to assess robustness:
  - observation-window length (12 / 18 / 24 h)
  - prediction horizon (24 / 48 / 72 h)
  - note availability (with-note vs without-note subgroups)
  - missingness/imputation strategy (cohort-median / fwd-fill-only / zero-fill)

Each configuration reuses the training and evaluation routines so that results
are directly comparable to the main analysis.
"""
import argparse
import numpy as np

from .utils import load_config, set_seed
from .train import train
from .evaluate import full_report


def run_observation_window(cfg, build_data_fn):
    results = {}
    for w in cfg["sensitivity"]["observation_windows_hours"]:
        c = _override(cfg, ["temporal_encoder", "time_steps"], w)
        c = _override(c, ["cohort", "observation_window_hours"], w)
        data = build_data_fn(c, observation_window=w)
        model = train(c, data)
        results[f"obs_{w}h"] = _eval_all(model, c, data)
    return results


def run_prediction_horizon(cfg, build_data_fn):
    results = {}
    for h in cfg["sensitivity"]["prediction_horizons_hours"]:
        c = _override(cfg, ["cohort", "outcome_window_hours"], h)
        data = build_data_fn(c, outcome_window=h)
        model = train(c, data)
        results[f"horizon_{h}h"] = _eval_all(model, c, data)
    return results


def run_note_availability(cfg, build_data_fn):
    """Stratify the held-out test set by note presence and report separately."""
    data = build_data_fn(cfg)
    model = train(cfg, data)
    results = {}
    for subset in cfg["sensitivity"]["note_availability"]:
        sub = build_data_fn(cfg, note_subset=subset)["test"]
        results[subset] = _eval_split(model, cfg, sub)
    return results


def run_imputation_variants(cfg, build_data_fn):
    results = {}
    for variant in cfg["sensitivity"]["imputation_variants"]:
        c = _override(cfg, ["preprocessing", "imputation"], variant)
        data = build_data_fn(c, imputation=variant)
        model = train(c, data)
        results[variant] = _eval_all(model, c, data)
    return results


# ---- helpers ----------------------------------------------------------------
def _override(cfg, keypath, value):
    import copy
    c = copy.deepcopy(cfg)
    d = c
    for k in keypath[:-1]:
        d = d[k]
    d[keypath[-1]] = value
    return c


def _eval_all(model, cfg, data):
    return _eval_split(model, cfg, data["test"])


def _eval_split(model, cfg, split):
    import torch
    from .utils import get_device
    device = get_device()
    X_seq, mask, emb, y = split
    model.eval()
    tasks = cfg["fusion"]["tasks"]
    with torch.no_grad():
        logits = model(
            torch.tensor(X_seq, dtype=torch.float32, device=device),
            torch.tensor(emb, dtype=torch.float32, device=device),
            torch.tensor(mask, dtype=torch.float32, device=device),
        )
    out = {}
    for j, t in enumerate(tasks):
        p = torch.sigmoid(logits[t]).cpu().numpy()
        out[t] = full_report(np.asarray(y[:, j]), p, cfg, label=t)
    return out


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()
    cfg = load_config(args.config)
    set_seed(cfg["seed"])
    print("Provide a build_data_fn(cfg, **kwargs) -> {'train','val','test'} and "
          "call the run_* functions to reproduce the sensitivity tables.")
