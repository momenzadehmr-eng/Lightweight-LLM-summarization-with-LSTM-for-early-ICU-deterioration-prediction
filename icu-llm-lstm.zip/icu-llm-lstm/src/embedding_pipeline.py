"""Embedding pipeline (Supplementary S1.5).

Transforms the 5 parsed template fields into a fixed 256-dim vector:
  1. Field-level encoding   : each field -> Flan-T5 encoder final hidden -> 1024
  2. Concatenation          : 5 x 1024 = 5120
  3. Linear projection      : 5120 -> 200 (jointly trained with LSTM backbone)
  4. Categorical append     : + 56 binary/one-hot features -> 256

The Flan-T5 encoder weights are frozen; only the linear projection is trained
end-to-end with the LSTM (Supplementary S1.5 note).
"""
import torch
import torch.nn as nn


class EmbeddingProjector(nn.Module):
    def __init__(self, cfg: dict):
        super().__init__()
        e = cfg["embedding"]
        self.proj = nn.Linear(e["projection_in"], e["projection_out"])  # 5120->200
        self.n_cat = e["n_categorical_features"]                        # 56
        self.out_dim = e["total_dim"]                                   # 256
        assert e["projection_out"] + self.n_cat == self.out_dim

    def forward(self, field_embeds, categorical):
        # field_embeds: (B, 5120) concatenated frozen encoder states
        # categorical:  (B, 56)   binary/one-hot comorbidity+intervention+status
        proj = self.proj(field_embeds)            # (B, 200)
        return torch.cat([proj, categorical], dim=1)  # (B, 256)


@torch.no_grad()
def encode_fields(summarizer, fields: dict) -> torch.Tensor:
    """Encode each of the 5 fields with the frozen Flan-T5 encoder.

    Returns a (5120,) vector = concat of 5 field-level 1024-dim representations
    (mean-pooled final encoder hidden state per field).
    """
    order = ["Admission", "Comorbidities", "Status", "Interventions", "Concerns"]
    vecs = []
    for k in order:
        text = fields.get(k, "NONE") or "NONE"
        enc = summarizer.tokenizer(text, return_tensors="pt",
                                   truncation=True, max_length=64).to(summarizer.device)
        out = summarizer.model.encoder(**enc)
        pooled = out.last_hidden_state.mean(dim=1).squeeze(0)  # (1024,)
        vecs.append(pooled)
    return torch.cat(vecs, dim=0)  # (5120,)
