"""Evaluation metrics (main text Section 2.7).

AUROC, AUPRC, Expected Calibration Error, decision-curve net benefit,
bootstrap 95% CIs (10,000 resamples), and DeLong's test for paired AUROC.
"""
import numpy as np
from sklearn.metrics import roc_auc_score, average_precision_score


# ----------------------------------------------------------------------------
def expected_calibration_error(y_true, y_prob, n_bins=10):
    """ECE with equal-frequency bins."""
    order = np.argsort(y_prob)
    y_true, y_prob = y_true[order], y_prob[order]
    bins = np.array_split(np.arange(len(y_prob)), n_bins)
    ece = 0.0
    n = len(y_prob)
    for b in bins:
        if len(b) == 0:
            continue
        conf = y_prob[b].mean()
        acc = y_true[b].mean()
        ece += (len(b) / n) * abs(acc - conf)
    return ece


# ----------------------------------------------------------------------------
def net_benefit(y_true, y_prob, threshold):
    """Decision-curve net benefit at a given probability threshold."""
    n = len(y_true)
    pred_pos = y_prob >= threshold
    tp = np.sum((pred_pos) & (y_true == 1))
    fp = np.sum((pred_pos) & (y_true == 0))
    w = threshold / (1 - threshold)
    return (tp / n) - (fp / n) * w


def decision_curve(y_true, y_prob, thresholds):
    return {round(t, 3): net_benefit(y_true, y_prob, t) for t in thresholds}


# ----------------------------------------------------------------------------
def bootstrap_ci(y_true, y_prob, metric_fn, n_boot=10000, seed=42):
    rng = np.random.default_rng(seed)
    n = len(y_true)
    stats = np.empty(n_boot)
    for i in range(n_boot):
        idx = rng.integers(0, n, n)
        try:
            stats[i] = metric_fn(y_true[idx], y_prob[idx])
        except ValueError:
            stats[i] = np.nan
    stats = stats[~np.isnan(stats)]
    point = metric_fn(y_true, y_prob)
    lo, hi = np.percentile(stats, [2.5, 97.5])
    return point, lo, hi


# ----------------------------------------------------------------------------
def _compute_midrank(x):
    J = np.argsort(x)
    Z = x[J]
    N = len(x)
    T = np.zeros(N)
    i = 0
    while i < N:
        j = i
        while j < N and Z[j] == Z[i]:
            j += 1
        T[i:j] = 0.5 * (i + j - 1) + 1
        i = j
    T2 = np.empty(N)
    T2[J] = T
    return T2


def delong_test(y_true, prob_a, prob_b):
    """Two-sided p-value for difference in AUROC (DeLong, correlated curves)."""
    from scipy import stats

    pos = y_true == 1
    neg = ~pos
    m, n = pos.sum(), neg.sum()
    preds = np.vstack([prob_a, prob_b])

    pos_p = preds[:, pos]
    neg_p = preds[:, neg]
    k = 2

    tx = np.array([_compute_midrank(pos_p[r]) for r in range(k)])
    ty = np.array([_compute_midrank(neg_p[r]) for r in range(k)])
    tz = np.array([_compute_midrank(np.concatenate([pos_p[r], neg_p[r]]))
                   for r in range(k)])

    aucs = (tz[:, :m].sum(axis=1) / m - (m + 1) / 2) / n
    v01 = (tz[:, :m] - tx) / n
    v10 = 1 - (tz[:, m:] - ty) / m
    sx = np.cov(v01)
    sy = np.cov(v10)
    s = sx / m + sy / n
    s = np.atleast_2d(s)
    L = np.array([[1, -1]])
    var = L @ s @ L.T
    z = (aucs[0] - aucs[1]) / np.sqrt(var[0, 0] + 1e-12)
    p = 2 * (1 - stats.norm.cdf(abs(z)))
    return float(aucs[0]), float(aucs[1]), float(p)


# ----------------------------------------------------------------------------
def full_report(y_true, y_prob, cfg, label=""):
    auroc = bootstrap_ci(y_true, y_prob, roc_auc_score,
                         cfg["evaluation"]["bootstrap_iterations"], cfg["seed"])
    auprc = bootstrap_ci(y_true, y_prob, average_precision_score,
                         cfg["evaluation"]["bootstrap_iterations"], cfg["seed"])
    ece = expected_calibration_error(y_true, y_prob, cfg["evaluation"]["ece_bins"])
    lo, hi = cfg["evaluation"]["decision_curve_thresholds"]
    thresholds = np.linspace(lo, hi, 26)
    dca = decision_curve(y_true, y_prob, thresholds)
    return {
        "label": label,
        "auroc": auroc,    # (point, lo, hi)
        "auprc": auprc,
        "ece": ece,
        "decision_curve": dca,
    }
