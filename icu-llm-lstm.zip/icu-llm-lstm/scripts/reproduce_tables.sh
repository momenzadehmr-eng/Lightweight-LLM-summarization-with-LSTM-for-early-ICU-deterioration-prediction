#!/usr/bin/env bash
# Reproduce the main result tables (Table 2, Table 3) and sensitivity tables.
set -euo pipefail
CONFIG="${1:-config/local_config.yaml}"

python -m src.evaluate    --config "$CONFIG"   # Table 2 (main performance)
python -m src.sensitivity --config "$CONFIG"   # reviewer sensitivity tables
echo "Outputs written to the configured output_dir."
