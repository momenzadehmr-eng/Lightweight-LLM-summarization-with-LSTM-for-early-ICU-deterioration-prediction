#!/usr/bin/env bash
# End-to-end pipeline. Requires a local MIMIC-IV v2.2 PostgreSQL instance and
# a configured config/local_config.yaml.
set -euo pipefail

CONFIG="${1:-config/local_config.yaml}"

echo "[1/6] SQL extraction (run manually against PostgreSQL):"
echo "      psql -d mimiciv -f sql/01_cohort_identification.sql"
echo "      psql -d mimiciv -f sql/02_vitalsigns_extraction.sql"
echo "      psql -d mimiciv -f sql/03_labs_extraction.sql"

echo "[2/6] Cohort build + exclusion flow"
python -m src.data_extraction --config "$CONFIG"

echo "[3/6] Temporal preprocessing"
python -m src.preprocessing --config "$CONFIG"

echo "[4/6] Note processing + LLM summarization + embeddings"
python -m src.note_processing --config "$CONFIG"
python -m src.llm_summarizer --config "$CONFIG"
python -m src.embedding_pipeline --config "$CONFIG"

echo "[5/6] Train multimodal model"
python -m src.train --config "$CONFIG"

echo "[6/6] Evaluate + sensitivity analyses"
python -m src.evaluate --config "$CONFIG"
python -m src.sensitivity --config "$CONFIG"

echo "Done."
