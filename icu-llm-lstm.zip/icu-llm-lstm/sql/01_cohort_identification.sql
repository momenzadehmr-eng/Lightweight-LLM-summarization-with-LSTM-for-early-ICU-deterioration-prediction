-- =============================================================================
-- 01_cohort_identification.sql
-- MIMIC-IV v2.2  |  PostgreSQL 15
-- Stage 1: base adult ICU cohort with LOS > 24h
-- Stage 2: require >= 1 clinical note within first 24h
-- (Stage 3 — >6h consecutive vital-sign gap exclusion — applied in Python)
-- =============================================================================

DROP TABLE IF EXISTS analysis.cohort_base;
CREATE TABLE analysis.cohort_base AS

WITH base AS (
    SELECT
        ie.subject_id,
        ie.hadm_id,
        ie.stay_id,
        ie.intime,
        ie.outtime,
        EXTRACT(EPOCH FROM (ie.outtime - ie.intime)) / 3600.0 AS los_hours,
        (p.anchor_age + EXTRACT(YEAR FROM ie.intime) - p.anchor_year) AS age_at_admit
    FROM mimiciv_icu.icustays ie
    INNER JOIN mimiciv_hosp.patients p
        ON ie.subject_id = p.subject_id
    WHERE EXTRACT(EPOCH FROM (ie.outtime - ie.intime)) / 3600.0 > 24      -- LOS > 24h
),

adult AS (
    SELECT *
    FROM base
    WHERE age_at_admit >= 18                                              -- adults
),

with_note AS (
    -- Stage 2: at least one note within the first 24h of ICU admission
    SELECT DISTINCT a.stay_id
    FROM adult a
    INNER JOIN mimiciv_note.discharge dn        -- + radiology/notes as applicable
        ON a.hadm_id = dn.hadm_id
    WHERE dn.charttime BETWEEN a.intime AND a.intime + INTERVAL '24 hours'
    -- NOTE: depending on the MIMIC-IV-Note table layout used, join on the
    -- appropriate note table(s) and restrict note_type to the configured set.
)

SELECT a.*
FROM adult a
INNER JOIN with_note wn ON a.stay_id = wn.stay_id;

-- Resulting count is reduced further by the Python gap-detection step
-- (>6h consecutive vital-sign gaps) and outcome-label completeness checks.
-- See Fig. S1 for the full exclusion flow from 73,181 raw stays to 50,318.
