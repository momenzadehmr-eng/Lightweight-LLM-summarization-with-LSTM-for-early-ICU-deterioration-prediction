-- =============================================================================
-- 03_labs_extraction.sql
-- Sixteen laboratory values, first 24h. itemids in data/itemid_reference.csv
-- =============================================================================

DROP TABLE IF EXISTS analysis.labs_hourly;
CREATE TABLE analysis.labs_hourly AS

WITH le AS (
    SELECT
        ie.stay_id,
        l.charttime,
        l.itemid,
        l.valuenum,
        FLOOR(EXTRACT(EPOCH FROM (l.charttime - ie.intime)) / 3600.0) AS hour_idx
    FROM mimiciv_hosp.labevents l
    INNER JOIN analysis.cohort_base ie
        ON l.hadm_id = ie.hadm_id
    WHERE l.charttime BETWEEN ie.intime AND ie.intime + INTERVAL '24 hours'
      AND l.valuenum IS NOT NULL
      AND l.itemid IN (
            -- 16 lab itemids; see data/itemid_reference.csv for the full mapping:
            -- lactate, creatinine, BUN, sodium, potassium, chloride,
            -- bicarbonate, glucose, WBC, hemoglobin, platelets, INR,
            -- bilirubin, albumin, pH, anion gap
            50813, 50912, 51006, 50983, 50971, 50902,
            50882, 50931, 51301, 51222, 51265, 51237,
            50885, 50862, 50820, 50868
      )
)

SELECT
    stay_id,
    hour_idx,
    itemid,
    AVG(valuenum) AS value_mean
FROM le
WHERE hour_idx BETWEEN 0 AND 23
GROUP BY stay_id, hour_idx, itemid
ORDER BY stay_id, hour_idx, itemid;
