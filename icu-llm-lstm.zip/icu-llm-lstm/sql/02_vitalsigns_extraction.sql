-- =============================================================================
-- 02_vitalsigns_extraction.sql
-- Eight vital signs, hourly, first 24h of ICU stay.
-- itemids per Supplementary Table S2 / data/itemid_reference.csv
-- =============================================================================

DROP TABLE IF EXISTS analysis.vitals_hourly;
CREATE TABLE analysis.vitals_hourly AS

WITH ce AS (
    SELECT
        c.stay_id,
        c.charttime,
        c.itemid,
        c.valuenum,
        FLOOR(EXTRACT(EPOCH FROM (c.charttime - ie.intime)) / 3600.0) AS hour_idx
    FROM mimiciv_icu.chartevents c
    INNER JOIN analysis.cohort_base ie ON c.stay_id = ie.stay_id
    WHERE c.charttime BETWEEN ie.intime AND ie.intime + INTERVAL '24 hours'
      AND c.valuenum IS NOT NULL
      AND c.itemid IN (
            220045,                  -- heart rate
            220179, 220050,          -- systolic BP (NIBP / ABP)
            220180, 220051,          -- diastolic BP
            220052, 220181,          -- mean arterial pressure
            220210, 224690,          -- respiratory rate
            223761, 223762,          -- temperature (F / C)
            220277,                  -- SpO2
            220739, 223900, 223901   -- GCS components
      )
)

SELECT
    stay_id,
    hour_idx,
    itemid,
    AVG(valuenum) AS value_mean        -- hourly mean within the slot
FROM ce
WHERE hour_idx BETWEEN 0 AND 23
GROUP BY stay_id, hour_idx, itemid
ORDER BY stay_id, hour_idx, itemid;

-- Physiologic outlier bounds and unit harmonisation (e.g. temperature F->C,
-- MAP computed as (SBP + 2*DBP)/3 when missing) are applied in
-- src/preprocessing.py per the rules in Supplementary Table S2.
